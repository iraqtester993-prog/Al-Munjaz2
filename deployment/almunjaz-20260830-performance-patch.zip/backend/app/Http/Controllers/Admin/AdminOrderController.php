<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\Branch;
use App\Models\Order;
use App\Models\OrderMovement;
use App\Models\Scopes\TenantScope;
use App\Models\User;
use App\Services\OrderOperationalAssignmentService;
use App\Services\OrderPickupRecoveryService;
use App\Services\OrderWorkflowService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Inertia\Inertia;

class AdminOrderController extends Controller
{
    public function index(Request $request)
    {
        $canUpdateOrders = $request->user()->canUseAdminPermission('orders', 'update');
        $rules = [
            'filter' => ['nullable', Rule::in(array_merge(['all', 'deleted'], Order::FILTERABLE_STATUSES))],
            'q' => ['nullable', 'string', 'max:120'],
            // The list is deliberately small.  These two JSON modes load a
            // single order's operational history or a management directory
            // only after an operator explicitly opens the relevant control.
            'detail' => ['nullable', 'integer', 'min:1'],
            'directory' => ['nullable', Rule::in(['courier_filters', 'assignment'])],
            'assignment_for' => [
                Rule::requiredIf(fn () => $request->input('directory') === 'assignment'),
                'nullable',
                'integer',
                'min:1',
            ],
        ];

        // Courier filtering is backed by the assignment directory below.
        // A view-only operator can inspect orders, but must not use a hidden
        // query parameter as an alternate way to inspect that directory.
        if ($canUpdateOrders) {
            $rules['courier_id'] = [
                // This is deliberately limited to direct-order roles. A branch
                // transporter can never be used as a hidden filter to inspect
                // unrelated order data through the operations dashboard.
                'nullable',
                'integer',
                Rule::exists('users', 'id')->where(fn ($users) => $users
                    ->whereIn('role', User::DIRECT_ORDER_COURIER_ROLES)
                    ->whereNull('deleted_at')),
            ];
        }

        $request->validate($rules);

        if ($request->filled('detail')) {
            abort_unless($request->expectsJson(), 406);

            return response()->json([
                'order' => $this->detailPayloadFor($request->integer('detail')),
            ]);
        }

        if ($request->filled('directory')) {
            abort_unless($request->expectsJson(), 406);
            abort_unless($canUpdateOrders, 403);

            return response()->json($this->directoryPayload(
                $request->string('directory')->toString(),
                $request->integer('assignment_for'),
            ));
        }

        // The operations dashboard serves the whole platform, including
        // merchant-owned orders and the shared branch network.
        $allOrders = Order::withoutGlobalScope(TenantScope::class);
        $filter = $request->input('filter', 'all');
        $showDeleted = $filter === 'deleted';

        // Deleted orders are never silently discarded. They remain available
        // to platform administration for review and a one-click restore.
        $query = $showDeleted
            ? (clone $allOrders)->onlyTrashed()
            : clone $allOrders;
        // Table rows contain just the data required to draw the table and
        // operate its controls. A full status/audit timeline for 25 orders
        // made the first dashboard response grow with every historic event.
        // It is now fetched only by the detail request above.
        $query = $query
            ->select($this->summaryColumns())
            ->with([
                'courier:id,name,phone,vehicle',
                'pickupCourier:id,name,phone,vehicle',
                'deliveryCourier:id,name,phone,vehicle',
                'merchant:id,name,phone,shop_name,address',
                'tenant:id,name',
                'province:id,name_ar,name_en,name_ku',
                'originBranch:id,name_ar,name_en,name_ku,city',
                'destinationBranch:id,name_ar,name_en,name_ku,city',
            ]);

        if ($filter !== 'all' && ! $showDeleted) {
            $query->operationalStatus($filter);
        }

        $q = trim((string) $request->input('q', ''));
        if ($q !== '') {
            $query->where(function ($b) use ($q) {
                $b->where('track_no', 'like', "%{$q}%")
                    ->orWhere('customer_name_ar', 'like', "%{$q}%")
                    ->orWhere('customer_name_en', 'like', "%{$q}%")
                    ->orWhere('phone', 'like', "%{$q}%")
                    ->orWhereHas('courier', fn ($courier) => $courier
                        ->where(fn ($match) => $match
                            ->where('name', 'like', "%{$q}%")
                            ->orWhere('phone', 'like', "%{$q}%")))
                    ->orWhereHas('pickupCourier', fn ($courier) => $courier
                        ->where(fn ($match) => $match
                            ->where('name', 'like', "%{$q}%")
                            ->orWhere('phone', 'like', "%{$q}%")))
                    ->orWhereHas('deliveryCourier', fn ($courier) => $courier
                        ->where(fn ($match) => $match
                            ->where('name', 'like', "%{$q}%")
                            ->orWhere('phone', 'like', "%{$q}%")));
            });
        }

        $courierId = $canUpdateOrders ? $request->integer('courier_id') : null;

        if ($courierId) {
            // A courier may own the whole order or only one operational leg.
            // All three links are intentionally included so the selector
            // reflects the actual work history of that courier.
            $query->where(function ($assignments) use ($courierId) {
                $assignments
                    ->where('courier_id', $courierId)
                    ->orWhere('pickup_courier_id', $courierId)
                    ->orWhere('delivery_courier_id', $courierId);
            });
        }

        $orders = $query->latest('id')->paginate(25)->withQueryString();
        $orders->through(fn (Order $order) => $this->summaryPayload($order));

        $counts = $this->countsFor($allOrders);

        return Inertia::render('Admin/Orders', [
            'orders' => $orders,
            'counts' => $counts,
            'filter' => $request->input('filter', 'all'),
            'q' => $q,
            'courierId' => $courierId ?: null,
            'canUpdateOrders' => $canUpdateOrders,
        ]);
    }

    /**
     * @return array<int, string>
     */
    private function summaryColumns(): array
    {
        return [
            'id',
            'track_no',
            'source',
            'status',
            'workflow_stage',
            'tenant_id',
            'merchant_id',
            'courier_id',
            'pickup_courier_id',
            'delivery_courier_id',
            'province_id',
            'origin_branch_id',
            'destination_branch_id',
            'customer_name_ar',
            'customer_name_en',
            'phone',
            'address_ar',
            'price',
            'fee',
            'date',
            'pickup_deadline_at',
            'deleted_at',
        ];
    }

    /**
     * Keep the initial table payload intentionally shallow. Full financial,
     * contact, route history and audit data are returned by detailPayloadFor.
     */
    private function summaryPayload(Order $order): array
    {
        return [
            'id' => $order->id,
            'track_no' => $order->track_no,
            'source' => $order->source,
            'status' => $order->status,
            'workflow_stage' => $order->workflow_stage,
            'tenant_id' => $order->tenant_id,
            'customer' => [
                'name' => $order->customer_name_ar,
                'name_en' => $order->customer_name_en,
                'phone' => $order->phone,
                'address' => $order->address_ar,
            ],
            'customer_name_ar' => $order->customer_name_ar,
            'phone' => $order->phone,
            'address_ar' => $order->address_ar,
            'price' => (int) $order->price,
            'fee' => $order->fee === null ? null : (int) $order->fee,
            'financial' => [
                'order_value' => (int) $order->price,
                'delivery_fee' => $order->fee === null ? null : (int) $order->fee,
            ],
            'date' => $order->date?->toDateString(),
            'deleted_at' => $this->iso($order->deleted_at),
            'pickup_deadline_at' => $this->iso($order->pickup_deadline_at),
            'province_id' => $order->province_id,
            'province' => $order->province ? [
                'id' => $order->province->id,
                'name_ar' => $order->province->name_ar,
                'name_en' => $order->province->name_en,
                'name_ku' => $order->province->name_ku,
            ] : null,
            'tenant' => $order->tenant?->name,
            'merchant' => $order->merchant ? [
                'id' => $order->merchant->id,
                'name' => $order->merchant->name,
                'shop_name' => $order->merchant->shop_name,
            ] : ($order->tenant ? [
                'id' => null,
                'name' => $order->tenant->name,
                'shop_name' => null,
            ] : null),
            'origin_branch_id' => $order->origin_branch_id,
            'destination_branch_id' => $order->destination_branch_id,
            'origin_branch' => $this->branchPayload($order->originBranch),
            'destination_branch' => $this->branchPayload($order->destinationBranch),
            'courier_id' => $order->courier_id,
            'pickup_courier_id' => $order->pickup_courier_id,
            'delivery_courier_id' => $order->delivery_courier_id,
            'courier' => $this->personPayload($order->courier),
            'pickup_courier' => $this->personPayload($order->pickupCourier),
            'delivery_courier' => $this->personPayload($order->deliveryCourier),
        ];
    }

    /**
     * A detail request is still served by the same protected dashboard route,
     * so a view-only operator gets no broader access than the table itself.
     */
    private function detailPayloadFor(int $orderId): array
    {
        $order = Order::withoutGlobalScope(TenantScope::class)
            ->withTrashed()
            ->with([
                'courier:id,name,phone,vehicle',
                'pickupCourier:id,name,phone,vehicle',
                'deliveryCourier:id,name,phone,vehicle',
                'merchant:id,name,phone,shop_name,address',
                'tenant:id,name',
                'province:id,name_ar,name_en,name_ku',
                'originBranch:id,name_ar,name_en,name_ku,city',
                'destinationBranch:id,name_ar,name_en,name_ku,city',
                'statusLogs' => fn ($logs) => $logs
                    ->with('user:id,name,role')
                    ->latest('created_at'),
                'movements' => fn ($movements) => $movements
                    ->withoutGlobalScope(TenantScope::class)
                    ->with('actor:id,name,role')
                    ->latest('occurred_at'),
            ])
            ->findOrFail($orderId);

        // Movements retain the branch that was selected at that point in the
        // route. Resolve those historical branches only for this one detail
        // sheet, rather than for every row of the table.
        $movementBranchIds = $order->movements
            ->flatMap(fn (OrderMovement $movement) => [$movement->from_branch_id, $movement->to_branch_id])
            ->filter()
            ->unique()
            ->values();

        $movementBranches = $movementBranchIds->isEmpty()
            ? collect()
            : Branch::withoutGlobalScope(TenantScope::class)
                ->withTrashed()
                ->whereIn('id', $movementBranchIds)
                ->get(['id', 'name_ar', 'name_en', 'name_ku', 'city'])
                ->keyBy('id');

        return $this->orderPayload($order, $movementBranches);
    }

    /**
     * @param  Builder<Order>  $allOrders
     * @return array<string, int>
     */
    private function countsFor($allOrders): array
    {
        $statusColumns = collect(Order::STATUSES)
            ->map(fn (string $status) => "COUNT(CASE WHEN status = ? THEN 1 END) AS `{$status}`")
            ->implode(', ');

        $summary = (clone $allOrders)
            ->selectRaw("COUNT(*) AS all_count, {$statusColumns}", Order::STATUSES)
            ->first();

        $counts = ['all' => (int) ($summary->all_count ?? 0)];
        foreach (Order::STATUSES as $status) {
            $counts[$status] = (int) ($summary->{$status} ?? 0);
        }

        // "late" is a calculated operational condition, not a status column,
        // and deleted records are intentionally kept in a separate review tab.
        $counts['late'] = (clone $allOrders)->operationalStatus('late')->count();
        $counts['deleted'] = (clone $allOrders)->onlyTrashed()->count();

        return $counts;
    }

    /**
     * Load management directories only when an administrator uses a filter or
     * opens an assignment dialog. They can be very large on a live platform.
     *
     * @return array<string, mixed>
     */
    private function directoryPayload(string $directory, int $assignmentFor): array
    {
        if ($directory === 'courier_filters') {
            return [
                'courierFilters' => User::query()
                    ->whereIn('role', User::DIRECT_ORDER_COURIER_ROLES)
                    ->orderBy('name')
                    ->get(['id', 'name', 'phone', 'role', 'status'])
                    ->map(fn (User $courier) => [
                        'id' => $courier->id,
                        'name' => $courier->name,
                        'phone' => $courier->phone,
                        'role' => $courier->role,
                        'status' => $courier->status,
                    ])->values(),
            ];
        }

        $order = Order::withoutGlobalScope(TenantScope::class)
            ->select(['id', 'tenant_id', 'province_id'])
            ->findOrFail($assignmentFor);

        $couriers = collect();
        if ($order->province_id) {
            $couriers = User::query()
                ->whereIn('role', User::DIRECT_ORDER_COURIER_ROLES)
                ->where('status', 'active')
                ->whereHas('provinces', fn ($provinces) => $provinces->whereKey($order->province_id))
                ->with('provinces:id,name_ar')
                ->get(['id', 'name', 'phone', 'role'])
                ->map(fn (User $courier) => [
                    'id' => $courier->id,
                    'name' => $courier->name,
                    'phone' => $courier->phone,
                    'role' => $courier->role,
                    'assignment_roles' => app(OrderOperationalAssignmentService::class)->modesFor($courier),
                    'provinces' => $courier->provinces->map(fn ($province) => [
                        'id' => $province->id,
                        'name_ar' => $province->name_ar,
                    ])->values(),
                ])->values();
        }

        $branches = Branch::withoutGlobalScope(TenantScope::class)
            ->where('is_active', true)
            ->where(function ($branchQuery) use ($order): void {
                $branchQuery
                    ->where('is_platform_managed', true)
                    ->orWhere('tenant_id', $order->tenant_id);
            })
            ->orderBy('name_ar')
            ->get(['id', 'tenant_id', 'code', 'name_ar', 'city', 'is_platform_managed'])
            ->map(fn (Branch $branch) => [
                'id' => $branch->id,
                'tenant_id' => $branch->tenant_id,
                'code' => $branch->code,
                'name' => $branch->name_ar,
                'city' => $branch->city,
                'is_platform_managed' => $branch->is_platform_managed,
            ])->values();

        return compact('couriers', 'branches');
    }

    public function status(Request $request, Order $order)
    {
        $request->validate([
            'status' => ['required', Rule::in(Order::STATUSES)],
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        app(OrderWorkflowService::class)->changeStatus($order, $request->input('status'), $request->user(), $request->input('note'));

        return back()->with('success', __('orders.status_changed'));
    }

    public function assignCourier(Request $request, Order $order)
    {
        $request->validate([
            'courier_id' => ['required', 'exists:users,id'],
            'assignment_role' => ['nullable', Rule::in(OrderOperationalAssignmentService::ASSIGNMENT_ROLES)],
        ]);

        $courier = User::findOrFail($request->integer('courier_id'));

        app(OrderOperationalAssignmentService::class)->assign(
            $order,
            $courier,
            $request->user(),
            $request->input('assignment_role'),
            'تم تعيين المندوب من لوحة الإدارة.',
        );

        return back()->with('success', __('orders.courier_assigned'));
    }

    /**
     * An overdue pickup is recoverable without inventing a sixth delivery
     * status. The service returns the reserved courier budget and offers the
     * same order again, leaving the operation in the normal audit trail.
     */
    public function reofferOverduePickup(Request $request, Order $order)
    {
        $data = $request->validate([
            'note' => ['nullable', 'string', 'max:255'],
        ]);

        app(OrderPickupRecoveryService::class)->reoffer(
            $order,
            $request->user(),
            $data['note'] ?? null,
        );

        return back()->with('success', 'تمت إعادة طرح الطلب، وأُعيدت الميزانية المحجوزة للمندوب السابق.');
    }

    public function assignBranches(Request $request, Order $order)
    {
        $data = $request->validate([
            'origin_branch_id' => ['nullable', 'integer', 'exists:branches,id'],
            'destination_branch_id' => ['nullable', 'integer', 'exists:branches,id'],
        ]);

        $branchIds = collect([$data['origin_branch_id'] ?? null, $data['destination_branch_id'] ?? null])
            ->filter()
            ->unique()
            ->values();

        abort_unless($branchIds->isNotEmpty(), 422, 'اختر فرعاً واحداً على الأقل.');

        $branches = Branch::withoutGlobalScope(TenantScope::class)
            ->availableForTenant((int) $order->tenant_id)
            ->whereIn('id', $branchIds)
            ->get();
        abort_unless(
            $branches->count() === $branchIds->count()
                && $branches->every(fn (Branch $branch) => $branch->canServeTenant((int) $order->tenant_id)),
            422,
            'يجب أن تكون الفروع نشطة وتتبع شبكة الإدارة أو حساب التاجر نفسه.'
        );

        $originId = $data['origin_branch_id'] ?? null;
        $destinationId = $data['destination_branch_id'] ?? null;
        $stage = $originId && $destinationId && $originId !== $destinationId
            ? 'awaiting_transfer'
            : 'at_origin_branch';

        $order->update([
            'origin_branch_id' => $originId,
            'destination_branch_id' => $destinationId,
            'branch_id' => $destinationId ?: $originId,
            'workflow_stage' => $stage,
        ]);

        OrderMovement::withoutGlobalScopes()->create([
            'tenant_id' => $order->tenant_id,
            'order_id' => $order->id,
            'from_branch_id' => $originId,
            'to_branch_id' => $destinationId,
            'actor_id' => $request->user()->id,
            'stage' => $stage,
            'note' => 'تم تحديد مسار الفروع من لوحة الإدارة.',
            'meta' => ['origin_branch_id' => $originId, 'destination_branch_id' => $destinationId],
            'occurred_at' => now(),
        ]);

        return back()->with('success', 'تم حفظ مسار الفروع للطلب.');
    }

    /**
     * Merchant deletion is deliberately a soft delete. Give an administrator
     * a safe recovery path instead of ever recreating an order by hand or
     * losing its activity, chat, and ledger references.
     */
    public function restore(Request $request, int $orderId)
    {
        $trackNo = DB::transaction(function () use ($request, $orderId): string {
            // Use an explicit id instead of the normal route binder, because
            // the global binder intentionally excludes soft-deleted orders.
            $order = Order::withoutGlobalScope(TenantScope::class)
                ->withTrashed()
                ->lockForUpdate()
                ->findOrFail($orderId);

            abort_unless($order->trashed(), 422, 'هذا الطلب ليس ضمن الطلبات المحذوفة.');

            $order->restore();

            ActivityLog::create([
                'tenant_id' => $order->tenant_id,
                'user_id' => $request->user()->id,
                'action' => 'order.restored_by_admin',
                'subject_type' => 'order',
                'subject_id' => $order->id,
                'data' => ['track_no' => $order->track_no, 'status' => $order->status],
                'ip' => $request->ip(),
            ]);

            return $order->track_no;
        });

        return back()->with('success', 'تمت استعادة الطلب '.$trackNo.'.');
    }

    /**
     * Keep the dashboard's list and detail sheet driven by one operational
     * payload.  The client never has to infer a route, a ledger amount, or a
     * history item from presentation-only data.
     */
    private function orderPayload(Order $order, $movementBranches): array
    {
        $fee = $order->fee === null ? null : (int) $order->fee;
        $merchant = $order->merchant
            ? [
                'id' => $order->merchant->id,
                'name' => $order->merchant->name,
                'shop_name' => $order->merchant->shop_name,
                'phone' => $order->merchant->phone,
                'address' => $order->merchant->address,
            ]
            : ($order->tenant ? [
                'id' => null,
                'name' => $order->tenant->name,
                'shop_name' => null,
                'phone' => null,
                'address' => null,
            ] : null);

        return [
            'id' => $order->id,
            'track_no' => $order->track_no,
            'source' => $order->source,
            'status' => $order->status,
            'workflow_stage' => $order->workflow_stage,
            'tenant_id' => $order->tenant_id,
            'tenant' => $order->tenant?->name,
            'customer' => [
                'name' => $order->customer_name_ar,
                'name_en' => $order->customer_name_en,
                'phone' => $order->phone,
                'phone2' => $order->phone2,
                'address' => $order->address_ar,
                'address_en' => $order->address_en,
            ],
            // Keep the flat keys while older dashboard views are still being
            // migrated, and expose structured data for the detail sheet.
            'customer_name_ar' => $order->customer_name_ar,
            'phone' => $order->phone,
            'address_ar' => $order->address_ar,
            'pickup_latitude' => $order->pickup_latitude === null ? null : (float) $order->pickup_latitude,
            'pickup_longitude' => $order->pickup_longitude === null ? null : (float) $order->pickup_longitude,
            'pickup_location_label' => $order->pickup_location_label,
            'price' => (int) $order->price,
            'fee' => $fee,
            // The pricing quote is immutable; the applied amount is written
            // only by the courier's two-step return workflow.
            'return_fee' => (int) ($order->return_fee ?? 0),
            'return_fee_applied' => (int) ($order->return_fee_applied ?? 0),
            'financial' => [
                'order_value' => (int) $order->price,
                'delivery_fee' => $fee,
                'net_to_merchant' => max(0, (int) $order->price - ($fee ?? 0)),
                'return_fee_quote' => (int) ($order->return_fee ?? 0),
                'return_fee_applied' => (int) ($order->return_fee_applied ?? 0),
                'returned_to_merchant_at' => $this->iso($order->returned_to_merchant_at),
                'return_fee_charged_at' => $this->iso($order->return_fee_charged_at),
            ],
            'order_type' => $order->order_type,
            'delivery_vehicle' => $order->delivery_vehicle,
            'vehicle_note' => $order->vehicle_note,
            'notes' => $order->notes,
            'date' => $order->date?->toDateString(),
            'created_at' => $this->iso($order->created_at),
            'updated_at' => $this->iso($order->updated_at),
            'deleted_at' => $this->iso($order->deleted_at),
            'accepted_at' => $this->iso($order->accepted_at),
            'picked_at' => $this->iso($order->picked_at),
            'delivered_at' => $this->iso($order->delivered_at),
            'returned_at' => $this->iso($order->returned_at),
            'returned_to_merchant_at' => $this->iso($order->returned_to_merchant_at),
            'return_fee_charged_at' => $this->iso($order->return_fee_charged_at),
            'pickup_deadline_at' => $this->iso($order->pickup_deadline_at),
            'province_id' => $order->province_id,
            'province' => $order->province ? [
                'id' => $order->province->id,
                'name_ar' => $order->province->name_ar,
                'name_en' => $order->province->name_en,
                'name_ku' => $order->province->name_ku,
            ] : null,
            'merchant' => $merchant,
            'origin_branch_id' => $order->origin_branch_id,
            'destination_branch_id' => $order->destination_branch_id,
            'origin_branch' => $this->branchPayload($order->originBranch),
            'destination_branch' => $this->branchPayload($order->destinationBranch),
            'courier' => $this->personPayload($order->courier),
            'pickup_courier' => $this->personPayload($order->pickupCourier),
            'delivery_courier' => $this->personPayload($order->deliveryCourier),
            'timeline' => $this->timelinePayload($order, $movementBranches, $merchant),
        ];
    }

    private function timelinePayload(Order $order, $movementBranches, ?array $merchant): array
    {
        $events = collect();
        $hasCreationLog = false;

        foreach ($order->statusLogs as $log) {
            $isCreated = $log->from_status === null;
            $hasCreationLog = $hasCreationLog || $isCreated;

            $events->push([
                'kind' => $isCreated ? 'created' : 'status',
                'status' => $log->to_status,
                'from_status' => $log->from_status,
                'stage' => null,
                'note' => $log->note,
                'actor' => $this->personPayload($log->user),
                'from_branch' => null,
                'to_branch' => null,
                'at' => $this->iso($log->created_at),
            ]);
        }

        if (! $hasCreationLog && $order->created_at) {
            $events->push([
                'kind' => 'created',
                'status' => $order->status,
                'from_status' => null,
                'stage' => 'created',
                'note' => null,
                'actor' => $merchant,
                'from_branch' => null,
                'to_branch' => null,
                'at' => $this->iso($order->created_at),
            ]);
        }

        foreach ($order->movements as $movement) {
            $events->push([
                'kind' => data_get($movement->meta, 'event') === 'courier_assignment' ? 'assignment' : 'movement',
                'status' => null,
                'from_status' => null,
                'stage' => $movement->stage,
                'note' => $movement->note,
                'actor' => $this->personPayload($movement->actor),
                'assignment_role' => data_get($movement->meta, 'assignment_role'),
                'assignee' => data_get($movement->meta, 'event') === 'courier_assignment' ? [
                    'id' => data_get($movement->meta, 'assignee_id'),
                    'name' => data_get($movement->meta, 'assignee_name'),
                    'role' => data_get($movement->meta, 'assignee_role'),
                ] : null,
                'from_branch' => $this->branchPayload($movementBranches->get($movement->from_branch_id)),
                'to_branch' => $this->branchPayload($movementBranches->get($movement->to_branch_id)),
                'at' => $this->iso($movement->occurred_at),
            ]);
        }

        return $events
            ->filter(fn (array $event) => filled($event['at']))
            ->sortByDesc('at')
            ->values()
            ->all();
    }

    private function personPayload(?User $user): ?array
    {
        return $user ? [
            'id' => $user->id,
            'name' => $user->name,
            'phone' => $user->phone,
            'vehicle' => $user->vehicle,
            'role' => $user->role,
        ] : null;
    }

    private function branchPayload(?Branch $branch): ?array
    {
        return $branch ? [
            'id' => $branch->id,
            'name' => $branch->name_ar,
            'name_en' => $branch->name_en,
            'name_ku' => $branch->name_ku,
            'city' => $branch->city,
        ] : null;
    }

    private function iso($value): ?string
    {
        if ($value instanceof \DateTimeInterface) {
            return $value->format(DATE_ATOM);
        }

        return filled($value)
            ? Carbon::parse($value)->toIso8601String()
            : null;
    }
}
